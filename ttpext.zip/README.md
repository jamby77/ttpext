# Chrome extension for thetrainingplan.co

Convert thetrainingplan.co usual tabbed page layout into a flat style web page, that is friendly to be saved as PDF
